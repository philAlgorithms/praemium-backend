$(document).ready(function(){
    var token = $("[name='_token']").val();
    var selected;
    var coinCode ='btc';
    var coinName = 'bitcoin';
    var prices;
    var amount = 50;

    var addressNotice = $('#notice-address');
    var qr = $("#pay-qr");
    var address = addressNotice.text();
    var trustId = 0;
    var qLink = qrLink(coinName, address, amount);	
	/*
    $.ajax({
	  type:"GET",
	  url:"/prices",
	  headers: {
            'Accept': 'application/json',
	    'XSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
	  },
	  error: function(err){
		  return err.responseJSON;
	    //showAlert('danger','Some error occured');
	  },
	  success:function(data){
		var neat = {
		    btc: data.bitcoin.usd,
		    bnb: data.binancecoin.usd,
		    doge: data.dogecoin.usd,
		    usdt: data.tether.usd,
		    ada: data.cardano.usd,
		    eth: data.ethereum.usd
		};
		  prices = neat;
	   },
    });
    */
    var depositAmount = $("#deposit-amount").val();
    setInterval(function(){
	$.ajax({
	  type:"GET",
	  url:"/prices",
	  headers: {
            'Accept': 'application/json',
	    'XSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
	  },
	  error: function(err){
		  return err.responseJSON;
	    //showAlert('danger','Some error occured');
	  },
	  success:function(data){
		var neat = {
		    btc: data.bitcoin.usd,
		    bnb: data.binancecoin.usd,
		    doge: data.dogecoin.usd,
		    usdt: data.tether.usd,
		    ada: data.cardano.usd,
		    eth: data.ethereum.usd
		};
		prices = new Object;
		prices = neat;
		amount = dollarToCoin(depositAmount, prices[coinCode]);
		$("#notice-price").text(amount);
		qLink = qrLink(coinName, address, amount);
		qr.attr('src',qLink);
	   },
	});
    }, 5000);

    $("#customDropdown").click(function(){
	document.getElementById("#customDropdown").addEventListener("click");
    });


    $("#switch-coin").change(function(){
	selected = $(this).val();
	coinCode = stringBefore(selected, "|");
	coinName = $("#"+coinCode+"-name").val();
	var coinId = stringBefore(stringAfter(selected, "|"),'-');

	var coinPrice = stringBetween(selected,'-',':');
	var coinEquivalent = dollarToCoin(depositAmount, coinPrice);
	address = stringBetween(selected,':','/');
	trustId = stringAfter(selected,'/');
	
	qLink = qrLink(coinName, address, amount);
	qr.attr('src',qLink);

	var liveCoin = $('#coin-stat');
	var coinLogo = $('#coin-logo');
	var coinNotice = $('#notice-coin');
	var priceNotice = $('#notice-price');
	var svgNotice = $('#notice-svg');

	var liveCoinSrc = "https://widget.coinlib.io/widget?type=single_v2&theme=light&coin_id=" + coinId + "&pref_coin_id=1505";
    	liveCoin.attr('src', liveCoinSrc);
	coinLogo.removeClass().addClass('cf cf-' + coinCode);
	    
	coinNotice.text(" "+coinCode);
	addressNotice.text(address);
	svgNotice.attr('src',getCoinSvg(coinCode));
	priceNotice.text(coinEquivalent);

	$("#stat-header").text('Live ' + coinCode.toUpperCase() + ' Statistics');
	    //a($("#"+coinCode+"-name").val());
    });


    $("#deposit-amount").keyup(function(){
	depositAmount = $(this).val();
	var amount = dollarToCoin($(this).val(), prices[coinCode]);
	$("#notice-price").text(amount);
	qLink = qrLink(coinName, address, amount);
	qr.attr('src',qLink);
    });

    $("#notice-clipboard").click(function(){
	var that = $(this);
	navigator.clipboard.writeText(address).then(function(){
	    return;
	});
    });

    $("#pay").click(function(){
	$.ajax({
	    type:"POST",
	    url:"api/trust-pay",
	    headers: {
            	'Accept': 'application/json',
	    	'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),

	    },
	    error: function(err){
		aJ(err);a('hi');
	    //showAlert('danger','Some error occured');
	    },
	    data: {
	      	amount: amount,
		id: trustId,
		address: address,
		token: token
	    },
	    success:function(data){
		window.location.href = data;
	   },
	});

    });
});
