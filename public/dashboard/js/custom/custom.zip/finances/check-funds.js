$(document).ready(function(){
    var submit = $(".check-btn");
    //var loading = submit.closest(".loading-btn");
    //var cancel = $('#btn-cancel');

    var token = $('[name="_token"]').val();

    submit.click(function(){
	var loading = $(this).closest(".card-pricing").find(".loading-btn");
	hideLoading(submit, $(".loading-btn"));
	showLoading($(this), loading);
	var thatBtn = $(this);
	var cost = $(this).closest(".card-pricing").find(".plan-cost").val();
	var modal = $(this).closest(".card-pricing").find(".subscribe-modal");
	$.ajax({
	    type:"GET",
	    url:"api/check-current-balance",
	    headers: {
            	'Accept': 'application/json',
	    	'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
	    },
	    error: function(err){
		hideLoading(thatBtn, loading);
		//var error = err.responseJSON;
 		Swal.fire({ 
		    icon: 'error',
		    title: 'Error',
		    text: 'Some error occurred. Please check internet connection'
		});

	/*       var data = error.data;
		if(error.type === 'validation'){
		    var message = data[Object.keys(data)[Object.keys(data).length - 1]];
		    Swal.fire({
		    	icon: 'error',
  		    	title: 'Error',
  		    	text: message
		    });
		}else{
		    var message = typeof(error.data) == 'string' ? error.data : 'Some error occurred. Please check internet connection';
		    Swal.fire({ 
		 	icon: 'error',
			title: 'Error',
			text: message
		    });
		}*/
	    },
	    data: {
		_token: token
	    },
	    success:function(data){
		var balance = Number(data);
		hideLoading(thatBtn, loading);
		if(balance==0){
		    Swal.fire(
      		    	'Successful',
      		    	'Vabbé',
      		    	'No funds'
		    );
		}else if(balance < Number(cost)){
		    Swal.fire({ 
		 	icon: 'error',
			title: 'Error',
			text: 'Insufficient funds'
		    });
	
		}else if(balance >= Number(cost)){
		    modal.modal('show');
		}
	    }
    	});
    });
});
