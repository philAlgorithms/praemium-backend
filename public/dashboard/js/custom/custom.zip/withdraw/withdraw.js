$(document).ready(function(){
    var selected;
    var coinCode ='btc';
    var prices;
    var addressNotice = $('#notice-address');
    var address = addressNotice.text();
    $.ajax({
	  type:"GET",
	  url:"/prices",
	  headers: {
            'Accept': 'application/json',
	    'XSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
	  },
	  error: function(err){
		  return err.responseJSON;
	    //showAlert('danger','Some error occured');
	  },
	  success:function(data){
		var neat = {
		    btc: data.bitcoin.usd,
		    bnb: data.binancecoin.usd,
		    doge: data.dogecoin.usd,
		    usdt: data.tether.usd,
		    ada: data.cardano.usd,
		    eth: data.ethereum.usd
		};
		  prices = neat;
	   },
    });
    var withdrawAmount = $("#withdraw-amount").val();
    setInterval(function(){
	$.ajax({
	  type:"GET",
	  url:"/prices",
	  headers: {
            'Accept': 'application/json',
	    'XSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
	  },
	  error: function(err){
		  aJ(err.responseJSON);
	    //showAlert('danger','Some error occured');
	  },
	  success:function(data){
		var neat = {
		    btc: data.bitcoin.usd,
		    bnb: data.binancecoin.usd,
		    doge: data.dogecoin.usd,
		    usdt: data.tether.usd,
		    ada: data.cardano.usd,
		    eth: data.ethereum.usd
		};
		prices = new Object;
		prices = neat;
		var amount = dollarToCoin(withdrawAmount, prices[coinCode]);
		$("#notice-price").text(amount);
	   },
	});
    }, 5000);

    $("#customDropdown").click(function(){
	document.getElementById("#customDropdown").addEventListener("click");
    });


    $("#switch-coin").change(function(){
	selected = $(this).val();
	coinCode = stringBefore(selected, "|");
	var coinId = stringBefore(stringAfter(selected, "|"),'-');
	var coinPrice = stringBefore(stringAfter(selected,'-'),':');
	var coinEquivalent = dollarToCoin(withdrawAmount, coinPrice);
	address = stringAfter(selected,':');

	var liveCoin = $('#coin-stat');
	var coinLogo = $('#coin-logo');
	var coinNotice = $('#notice-coin');
	var priceNotice = $('#notice-price');
	var svgNotice = $('#notice-svg');

	var liveCoinSrc = "https://widget.coinlib.io/widget?type=single_v2&theme=light&coin_id=" + coinId + "&pref_coin_id=1505";
    	liveCoin.attr('src', liveCoinSrc);
	coinLogo.removeClass().addClass('cf cf-' + coinCode);
	    
	coinNotice.text(" "+coinCode);
	priceNotice.text(coinEquivalent);
	addressNotice.text(address);
	svgNotice.attr('src',getCoinSvg(coinCode));
	$("#stat-header").text('Live ' + coinCode.toUpperCase() + ' Statistics');
    });


    $("#withdraw-amount").keyup(function(){
	withdrawAmount = $(this).val();
	var amount = dollarToCoin($(this).val(), prices[coinCode]);
	$("#notice-price").text(amount);
    });

    $("#notice-clipboard").click(function(){
	var that = $(this);
	navigator.clipboard.writeText(address).then(function(){
	    return;
	});
    });

    $("#withdraw").click(function(){
	a('coming soon');
    });
});
